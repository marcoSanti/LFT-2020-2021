/**
 
	COLLEZIONE DI INTERI statiche che vengono usati come tag
	si possono accedere come Tag.EOF per esempio senza poterle però modificare!
	I tag sono le "categorie" dei vari tipi di token che vengono accettati

 */
public class Tag {
    public final static int
	EOF     = -1, 
	NUM     =  256, 
	ID      =  257, 
	RELOP   =  258,
	COND    =  259, 
	WHEN    =  260, 
	THEN    =  261, 
	ELSE    =  262, 
	WHILE   =  263, 
	DO      =  264, 
	SEQ     =  265, 
	PRINT   =  266, 
	READ    =  267, 
	OR      =  268, 
	AND     =  269;
}
